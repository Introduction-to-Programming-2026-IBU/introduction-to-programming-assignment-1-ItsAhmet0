from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from cs50 import SQL
from functools import wraps

app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQL("sqlite:///flashcards.db")


@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# ── helpers ──────────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("user_id"):
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated

# ── auth ─────────────────────────────────────────────────────────────────────

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm  = request.form.get("confirmation", "")
        if not username:
            flash("Username is required.")
            return render_template("register.html")
        if not password or password != confirm:
            flash("Passwords must match.")
            return render_template("register.html")
        if db.execute("SELECT id FROM users WHERE username = ?", username):
            flash("Username already taken.")
            return render_template("register.html")
        uid = db.execute("INSERT INTO users (username, hash) VALUES (?, ?)",
                         username, generate_password_hash(password))
        session["user_id"] = uid
        session["username"] = username
        flash("Welcome to FlashCS50! Create your first deck below.")
        return redirect("/")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    session.clear()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        rows = db.execute("SELECT * FROM users WHERE username = ?", username)
        if not rows or not check_password_hash(rows[0]["hash"], password):
            flash("Invalid username or password.")
            return render_template("login.html")
        session["user_id"] = rows[0]["id"]
        session["username"] = rows[0]["username"]
        return redirect("/")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# ── dashboard ────────────────────────────────────────────────────────────────

@app.route("/")
@login_required
def index():
    decks = db.execute("""
        SELECT d.id, d.title, d.description,
               COUNT(c.id) AS card_count,
               COALESCE(SUM(CASE WHEN c.known = 1 THEN 1 ELSE 0 END), 0) AS known_count
        FROM decks d
        LEFT JOIN cards c ON d.id = c.deck_id
        WHERE d.user_id = ?
        GROUP BY d.id
        ORDER BY d.created_at DESC
    """, session["user_id"])
    return render_template("index.html", decks=decks)

# ── decks ────────────────────────────────────────────────────────────────────

@app.route("/decks/new", methods=["GET", "POST"])
@login_required
def new_deck():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        desc  = request.form.get("description", "").strip()
        if not title:
            flash("Deck title is required.")
            return render_template("deck_form.html", deck=None)
        deck_id = db.execute(
            "INSERT INTO decks (user_id, title, description) VALUES (?, ?, ?)",
            session["user_id"], title, desc
        )
        flash(f'Deck "{title}" created!')
        return redirect(f"/decks/{deck_id}")
    return render_template("deck_form.html", deck=None)


@app.route("/decks/<int:deck_id>")
@login_required
def view_deck(deck_id):
    deck = db.execute("SELECT * FROM decks WHERE id = ? AND user_id = ?",
                      deck_id, session["user_id"])
    if not deck:
        flash("Deck not found.")
        return redirect("/")
    cards = db.execute("SELECT * FROM cards WHERE deck_id = ? ORDER BY id", deck_id)
    return render_template("deck.html", deck=deck[0], cards=cards)


@app.route("/decks/<int:deck_id>/edit", methods=["GET", "POST"])
@login_required
def edit_deck(deck_id):
    deck = db.execute("SELECT * FROM decks WHERE id = ? AND user_id = ?",
                      deck_id, session["user_id"])
    if not deck:
        return redirect("/")
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        desc  = request.form.get("description", "").strip()
        if title:
            db.execute("UPDATE decks SET title = ?, description = ? WHERE id = ?",
                       title, desc, deck_id)
            flash("Deck updated.")
        return redirect(f"/decks/{deck_id}")
    return render_template("deck_form.html", deck=deck[0])


@app.route("/decks/<int:deck_id>/delete", methods=["POST"])
@login_required
def delete_deck(deck_id):
    deck = db.execute("SELECT id FROM decks WHERE id = ? AND user_id = ?",
                      deck_id, session["user_id"])
    if not deck:
        flash("Deck not found.")
        return redirect("/")
    db.execute("DELETE FROM cards WHERE deck_id = ?", deck_id)
    db.execute("DELETE FROM decks WHERE id = ?", deck_id)
    flash("Deck deleted.")
    return redirect("/")

# ── cards ────────────────────────────────────────────────────────────────────

@app.route("/decks/<int:deck_id>/cards/new", methods=["GET", "POST"])
@login_required
def new_card(deck_id):
    deck = db.execute("SELECT * FROM decks WHERE id = ? AND user_id = ?",
                      deck_id, session["user_id"])
    if not deck:
        return redirect("/")
    if request.method == "POST":
        front = request.form.get("front", "").strip()
        back  = request.form.get("back", "").strip()
        if front and back:
            db.execute("INSERT INTO cards (deck_id, front, back) VALUES (?, ?, ?)",
                       deck_id, front, back)
            if request.form.get("add_another"):
                flash("Card added! Add another.")
                return redirect(f"/decks/{deck_id}/cards/new")
            return redirect(f"/decks/{deck_id}")
        flash("Both front and back are required.")
    return render_template("card_form.html", deck=deck[0], card=None)


@app.route("/cards/<int:card_id>/edit", methods=["GET", "POST"])
@login_required
def edit_card(card_id):
    card = db.execute("""
        SELECT c.*, d.user_id FROM cards c
        JOIN decks d ON c.deck_id = d.id
        WHERE c.id = ? AND d.user_id = ?
    """, card_id, session["user_id"])
    if not card:
        return redirect("/")
    if request.method == "POST":
        front = request.form.get("front", "").strip()
        back  = request.form.get("back", "").strip()
        if front and back:
            db.execute("UPDATE cards SET front = ?, back = ? WHERE id = ?",
                       front, back, card_id)
        return redirect(f"/decks/{card[0]['deck_id']}")
    return render_template("card_form.html", deck={"id": card[0]["deck_id"]}, card=card[0])


@app.route("/cards/<int:card_id>/delete", methods=["POST"])
@login_required
def delete_card(card_id):
    card = db.execute("""
        SELECT c.deck_id FROM cards c
        JOIN decks d ON c.deck_id = d.id
        WHERE c.id = ? AND d.user_id = ?
    """, card_id, session["user_id"])
    if card:
        deck_id = card[0]["deck_id"]
        db.execute("DELETE FROM cards WHERE id = ?", card_id)
        return redirect(f"/decks/{deck_id}")
    return redirect("/")


@app.route("/api/cards/<int:card_id>/known", methods=["POST"])
@login_required
def mark_known(card_id):
    data = request.get_json()
    known = 1 if data.get("known") else 0
    db.execute("UPDATE cards SET known = ? WHERE id = ?", known, card_id)
    return jsonify({"ok": True})

# ── study mode ───────────────────────────────────────────────────────────────

@app.route("/decks/<int:deck_id>/study")
@login_required
def study(deck_id):
    deck = db.execute("SELECT * FROM decks WHERE id = ? AND user_id = ?",
                      deck_id, session["user_id"])
    if not deck:
        return redirect("/")
    cards = db.execute("SELECT * FROM cards WHERE deck_id = ? ORDER BY RANDOM()", deck_id)
    if not cards:
        flash("Add some cards before studying!")
        return redirect(f"/decks/{deck_id}")
    return render_template("study.html", deck=deck[0], cards=cards)


@app.route("/decks/<int:deck_id>/reset", methods=["POST"])
@login_required
def reset_deck(deck_id):
    db.execute("""
        UPDATE cards SET known = 0
        WHERE deck_id = ? AND deck_id IN
            (SELECT id FROM decks WHERE user_id = ?)
    """, deck_id, session["user_id"])
    return redirect(f"/decks/{deck_id}/study")
