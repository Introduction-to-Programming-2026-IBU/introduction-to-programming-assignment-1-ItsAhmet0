# FlashCS50 — Flashcard Study App
### Final Project

## Video Demo
<URL HERE>

---

## Description
FlashCS50 is a web-based flashcard study application built with Flask, SQLite, HTML/CSS, JavaScript, and Bootstrap. It lets users create decks of flashcards, study them with a 3D flip animation, and track which cards they have memorised.

## Features

| Feature | Details |
|---|---|
| **User Authentication** | Register / login / logout with hashed passwords (`werkzeug`) |
| **Decks** | Create, edit, delete named decks with an optional description |
| **Cards** | Add, edit, delete question/answer cards inside any deck |
| **Study Mode** | Animated 3D card flip (CSS `perspective` + `rotateY`), navigate with buttons or keyboard |
| **Known tracking** | Mark individual cards as "known"; progress bar on dashboard |
| **Keyboard shortcuts** | Space = flip, ← → = navigate, K = mark known |

## Files

```
final_project/
├── app.py              # Flask routes and application logic
├── schema.sql          # Database schema (users, decks, cards)
├── requirements.txt    # Python dependencies
├── static/
│   ├── css/style.css   # Custom CSS incl. card flip animation
│   └── js/app.js       # Study-mode JavaScript
└── templates/
    ├── layout.html     # Base template (navbar, flash messages)
    ├── index.html      # Dashboard — deck grid with progress bars
    ├── deck.html       # Deck detail — card table
    ├── deck_form.html  # Create / edit deck
    ├── card_form.html  # Create / edit card
    ├── study.html      # Study mode with flip card UI
    ├── login.html
    └── register.html
```

## Design Decisions

**Why Flask + cs50.SQL?**  
Flask is lightweight and perfectly sized for a project of this scope. The cs50 SQL library abstracts away connection boilerplate while keeping queries explicit and readable.

**Why store `known` per-card instead of per-session?**  
Persisting `known` state to the database means progress is not lost when the user closes the browser. A future improvement would be a separate `study_sessions` table to track per-session statistics without overwriting long-term progress.

**The flip animation**  
The 3D card effect uses CSS `perspective` on the parent container and `transform: rotateY(180deg)` toggled by a JavaScript class. `backface-visibility: hidden` hides the reverse face until the rotation passes 90°, creating an illusion of a physical card.

**"Add & Another" button**  
When building a large deck, users typically want to add many cards in a row. The secondary submit button passes `add_another=1` in the form body; the server detects this and redirects back to the same form instead of the deck page.

## How to Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Create the database
cat schema.sql | sqlite3 flashcards.db

# 3. Start the server
flask run
```

Then open http://127.0.0.1:5000 in your browser.

---

