// ── Flashcard Flip ───────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
    const scene = document.querySelector(".flashcard-scene");
    if (scene) {
        scene.addEventListener("click", () => {
            scene.querySelector(".flashcard").classList.toggle("flipped");
        });
    }
});

// ── Study Mode ───────────────────────────────────────────────────────────────
let cards = [];
let currentIndex = 0;

function initStudy(cardData) {
    cards = cardData;
    showCard(0);
    updateCounter();
}

function showCard(index) {
    if (!cards.length) return;
    const card = cards[index];
    document.getElementById("card-front").textContent = card.front;
    document.getElementById("card-back").textContent  = card.back;
    document.querySelector(".flashcard").classList.remove("flipped");

    const knownBtn = document.getElementById("btn-known");
    if (knownBtn) {
        knownBtn.textContent = card.known ? "✓ Known" : "Mark Known";
        knownBtn.classList.toggle("opacity-50", !!card.known);
    }
    updateCounter();
}

function nextCard() {
    currentIndex = (currentIndex + 1) % cards.length;
    showCard(currentIndex);
}

function prevCard() {
    currentIndex = (currentIndex - 1 + cards.length) % cards.length;
    showCard(currentIndex);
}

function toggleKnown() {
    const card = cards[currentIndex];
    card.known = card.known ? 0 : 1;
    fetch(`/api/cards/${card.id}/known`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ known: card.known })
    });
    const btn = document.getElementById("btn-known");
    btn.textContent = card.known ? "✓ Known" : "Mark Known";
    btn.classList.toggle("opacity-50", !!card.known);
    updateCounter();
}

function updateCounter() {
    const el = document.getElementById("study-counter");
    if (!el || !cards.length) return;
    const known = cards.filter(c => c.known).length;
    el.textContent = `${currentIndex + 1} / ${cards.length}  ·  ${known} known`;
}
