import csv
import datetime
import pytz
import requests
import urllib
import uuid

from flask import redirect, render_template, request, session
from functools import wraps


def apology(message, code=400):
    def escape(s):
        for old, new in [("-", "--"), (" ", "-"), ("_", "__"), ("?", "~q"),
                         ("%", "~p"), ("#", "~h"), ("/", "~s"), ("\"", "''")]:
            s = s.replace(old, new)
        return s
    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function


def lookup(symbol):
    # Use Yahoo Finance API
    try:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote_plus(symbol)}"
        headers = {"User-Agent": "python-requests/2.27.1", "Accept": "*/*"}
        response = requests.get(url, headers=headers, timeout=5)
        response.raise_for_status()
        data = response.json()
        price = data["chart"]["result"][0]["meta"]["regularMarketPrice"]
        name = data["chart"]["result"][0]["meta"].get("shortName", symbol)
        return {"name": name, "price": float(price), "symbol": symbol.upper()}
    except Exception:
        return None


def usd(value):
    return f"${value:,.2f}"
