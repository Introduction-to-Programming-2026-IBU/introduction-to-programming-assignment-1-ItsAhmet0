import os
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import apology, login_required, lookup, usd

app = Flask(__name__)
app.jinja_env.filters["usd"] = usd

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQL("sqlite:///finance.db")


@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    holdings = db.execute(
        "SELECT symbol, SUM(shares) as shares FROM transactions WHERE user_id=? GROUP BY symbol HAVING SUM(shares)>0",
        session["user_id"]
    )
    cash = db.execute("SELECT cash FROM users WHERE id=?", session["user_id"])[0]["cash"]
    total = cash
    for h in holdings:
        quote = lookup(h["symbol"])
        h["price"] = quote["price"]
        h["name"] = quote["name"]
        h["total"] = h["price"] * h["shares"]
        total += h["total"]
    return render_template("index.html", holdings=holdings, cash=cash, total=total)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    if request.method == "POST":
        symbol = request.form.get("symbol", "").upper()
        shares = request.form.get("shares")
        if not symbol:
            return apology("must provide symbol")
        try:
            shares = int(shares)
            if shares < 1:
                raise ValueError
        except (ValueError, TypeError):
            return apology("shares must be a positive integer")

        quote = lookup(symbol)
        if not quote:
            return apology("invalid symbol")

        cost = quote["price"] * shares
        cash = db.execute("SELECT cash FROM users WHERE id=?", session["user_id"])[0]["cash"]
        if cash < cost:
            return apology("can't afford")

        db.execute("UPDATE users SET cash=cash-? WHERE id=?", cost, session["user_id"])
        db.execute(
            "INSERT INTO transactions (user_id, symbol, shares, price) VALUES (?,?,?,?)",
            session["user_id"], symbol, shares, quote["price"]
        )
        flash(f"Bought {shares} share(s) of {symbol}!")
        return redirect("/")
    return render_template("buy.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    holdings = db.execute(
        "SELECT symbol, SUM(shares) as shares FROM transactions WHERE user_id=? GROUP BY symbol HAVING SUM(shares)>0",
        session["user_id"]
    )
    if request.method == "POST":
        symbol = request.form.get("symbol", "").upper()
        shares = request.form.get("shares")
        try:
            shares = int(shares)
            if shares < 1:
                raise ValueError
        except (ValueError, TypeError):
            return apology("shares must be a positive integer")

        owned = next((h["shares"] for h in holdings if h["symbol"] == symbol), 0)
        if shares > owned:
            return apology("too many shares")

        quote = lookup(symbol)
        revenue = quote["price"] * shares
        db.execute("UPDATE users SET cash=cash+? WHERE id=?", revenue, session["user_id"])
        db.execute(
            "INSERT INTO transactions (user_id, symbol, shares, price) VALUES (?,?,?,?)",
            session["user_id"], symbol, -shares, quote["price"]
        )
        flash(f"Sold {shares} share(s) of {symbol}!")
        return redirect("/")
    return render_template("sell.html", holdings=holdings)


@app.route("/history")
@login_required
def history():
    transactions = db.execute(
        "SELECT symbol, shares, price, timestamp FROM transactions WHERE user_id=? ORDER BY timestamp DESC",
        session["user_id"]
    )
    return render_template("history.html", transactions=transactions)


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    if request.method == "POST":
        symbol = request.form.get("symbol", "").upper()
        if not symbol:
            return apology("must provide symbol")
        quote = lookup(symbol)
        if not quote:
            return apology("invalid symbol")
        return render_template("quoted.html", quote=quote)
    return render_template("quote.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    session.clear()
    if request.method == "POST":
        if not request.form.get("username"):
            return apology("must provide username", 403)
        if not request.form.get("password"):
            return apology("must provide password", 403)
        rows = db.execute("SELECT * FROM users WHERE username=?", request.form.get("username"))
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)
        session["user_id"] = rows[0]["id"]
        return redirect("/")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")
        if not username:
            return apology("must provide username")
        if not password:
            return apology("must provide password")
        if password != confirmation:
            return apology("passwords do not match")
        existing = db.execute("SELECT id FROM users WHERE username=?", username)
        if existing:
            return apology("username already taken")
        db.execute(
            "INSERT INTO users (username, hash) VALUES (?,?)",
            username, generate_password_hash(password)
        )
        rows = db.execute("SELECT id FROM users WHERE username=?", username)
        session["user_id"] = rows[0]["id"]
        flash("Registered!")
        return redirect("/")
    return render_template("register.html")


@app.route("/add_cash", methods=["GET", "POST"])
@login_required
def add_cash():
    """Personal touch: allow user to add cash."""
    if request.method == "POST":
        try:
            amount = float(request.form.get("amount"))
            if amount <= 0:
                raise ValueError
        except (ValueError, TypeError):
            return apology("invalid amount")
        db.execute("UPDATE users SET cash=cash+? WHERE id=?", amount, session["user_id"])
        flash(f"Added {usd(amount)} to your account!")
        return redirect("/")
    return render_template("add_cash.html")
