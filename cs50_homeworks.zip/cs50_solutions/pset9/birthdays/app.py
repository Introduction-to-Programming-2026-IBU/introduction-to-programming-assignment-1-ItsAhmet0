from flask import Flask, redirect, render_template, request
from cs50 import SQL

app = Flask(__name__)
db = SQL("sqlite:///birthdays.db")

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        name = request.form.get("name")
        month = request.form.get("month")
        day = request.form.get("day")

        if not name or not month or not day:
            return redirect("/")
        try:
            month = int(month)
            day = int(day)
        except ValueError:
            return redirect("/")

        if not (1 <= month <= 12) or not (1 <= day <= 31):
            return redirect("/")

        db.execute("INSERT INTO birthdays (name, month, day) VALUES (?, ?, ?)", name, month, day)
        return redirect("/")

    birthdays = db.execute("SELECT * FROM birthdays ORDER BY month, day")
    return render_template("index.html", birthdays=birthdays)

@app.route("/delete/<int:id>")
def delete(id):
    db.execute("DELETE FROM birthdays WHERE id = ?", id)
    return redirect("/")
