-- Fiftyville Mystery Solution Log
-- Goal: Find the thief, the city they escaped to, and their accomplice.

-- STEP 1: Find the crime scene description
SELECT description FROM crime_scene_reports
WHERE year = 2021 AND month = 7 AND day = 28 AND street = 'Humphrey Street';
-- Result: Theft at bakery at 10:15am. Three witnesses interviewed, each mentions the bakery.

-- STEP 2: Read the three witness interviews
SELECT name, transcript FROM interviews
WHERE year = 2021 AND month = 7 AND day = 28 AND transcript LIKE '%bakery%';
-- Ruth:   saw thief get into a car in bakery parking lot (10:15-10:25)
-- Eugene: recognized thief, saw them withdraw money from Leggett Street ATM before 10am
-- Raymond: thief called someone to buy earliest flight out of Fiftyville on July 29, leaving <1 min

-- STEP 3: Check bakery security logs (10:15 - 10:25)
SELECT activity, license_plate, hour, minute FROM bakery_security_logs
WHERE year = 2021 AND month = 7 AND day = 28
AND hour = 10 AND minute BETWEEN 15 AND 25 AND activity = 'exit';
-- Plates: 5P2BI95, 94KL13X, 6P58WS2, 4328GD8, G412CB7, L93JTIZ, 322W7JE, 0NTHK55

-- STEP 4: Check ATM withdrawals on Leggett Street before 10am
SELECT account_number, amount FROM atm_transactions
WHERE year = 2021 AND month = 7 AND day = 28
AND atm_location = 'Leggett Street' AND transaction_type = 'withdraw';

-- STEP 5: Find earliest flights out of Fiftyville on July 29
SELECT flights.id, hour, minute, city FROM flights
JOIN airports ON flights.destination_airport_id = airports.id
WHERE origin_airport_id = (SELECT id FROM airports WHERE city = 'Fiftyville')
AND year = 2021 AND month = 7 AND day = 29
ORDER BY hour, minute LIMIT 1;
-- Flight 36 at 8:20am -> New York City

-- STEP 6: Find passengers on flight 36 who match bakery plates & ATM withdrawals
SELECT name FROM people
WHERE passport_number IN (
    SELECT passport_number FROM passengers WHERE flight_id = 36
)
AND license_plate IN ('5P2BI95','94KL13X','6P58WS2','4328GD8','G412CB7','L93JTIZ','322W7JE','0NTHK55')
AND id IN (
    SELECT person_id FROM bank_accounts
    JOIN atm_transactions ON bank_accounts.account_number = atm_transactions.account_number
    WHERE year = 2021 AND month = 7 AND day = 28
    AND atm_location = 'Leggett Street' AND transaction_type = 'withdraw'
);
-- Result: Bruce

-- STEP 7: Find the accomplice (person Bruce called < 1 min on July 28)
SELECT name FROM people
WHERE phone_number IN (
    SELECT receiver FROM phone_calls
    WHERE year = 2021 AND month = 7 AND day = 28 AND duration < 60
    AND caller = (SELECT phone_number FROM people WHERE name = 'Bruce')
);
-- Result: Robin

-- ANSWERS:
-- Thief:        Bruce
-- Escaped to:   New York City
-- Accomplice:   Robin
