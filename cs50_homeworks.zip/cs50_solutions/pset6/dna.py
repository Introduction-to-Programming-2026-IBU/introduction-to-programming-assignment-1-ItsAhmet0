import csv
import sys

def main():
    if len(sys.argv) != 3:
        print("Usage: python dna.py database.csv sequence.txt")
        sys.exit(1)

    with open(sys.argv[1]) as f:
        reader = csv.DictReader(f)
        strs = reader.fieldnames[1:]
        people = list(reader)

    with open(sys.argv[2]) as f:
        sequence = f.read()

    counts = {s: longest_run(sequence, s) for s in strs}

    for person in people:
        if all(int(person[s]) == counts[s] for s in strs):
            print(person["name"])
            return
    print("No match")

def longest_run(sequence, sub):
    max_run = 0
    i = 0
    while i < len(sequence):
        count = 0
        while sequence[i:i + len(sub)] == sub:
            count += 1
            i += len(sub)
        max_run = max(max_run, count)
        i += 1
    return max_run

main()
