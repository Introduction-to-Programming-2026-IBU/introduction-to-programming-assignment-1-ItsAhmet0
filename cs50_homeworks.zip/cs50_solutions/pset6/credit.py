def main():
    number = get_number()
    if is_valid(number):
        print(card_type(number))
    else:
        print("INVALID")

def get_number():
    while True:
        try:
            n = int(input("Number: "))
            if n > 0:
                return n
        except ValueError:
            pass

def is_valid(number):
    digits = [int(d) for d in str(number)]
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0

def card_type(number):
    s = str(number)
    length = len(s)
    if length == 15 and s[:2] in ("34", "37"):
        return "AMEX"
    elif length == 16 and s[:2] in ("51", "52", "53", "54", "55"):
        return "MASTERCARD"
    elif length in (13, 16) and s[0] == "4":
        return "VISA"
    return "INVALID"

main()
