#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int cents;
    do
    {
        cents = get_int("Change owed: ");
    }
    while (cents < 0);

    int coins = 0;

    // quarters
    coins += cents / 25;
    cents = cents % 25;

    // dimes
    coins += cents / 10;
    cents = cents % 10;

    // nickels
    coins += cents / 5;
    cents = cents % 5;

    // pennies
    coins += cents;

    printf("%i\n", coins);
}

