#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int height;

    // keep asking until we get a valid height
    do
    {
        height = get_int("Height: ");
    }
    while (height < 1 || height > 8);

    for (int row = 0; row < height; row++)
    {
        // left side spaces
        for (int s = 0; s < height - row - 1; s++)
        {
            printf(" ");
        }

        // left side hashes
        for (int h = 0; h <= row; h++)
        {
            printf("#");
        }

        // gap in the middle
        printf("  ");

        // right side hashes
        for (int h = 0; h <= row; h++)
        {
            printf("#");
        }

        printf("\n");
    }
}
