// Implements a dictionary's functionality

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "dictionary.h"

// represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// picked a decent-sized table to reduce collisions
const unsigned int N = 65536;

// hash table
node *table[N];

// keeps track of how many words we loaded
unsigned int word_count = 0;

// hash function — djb2 variant
// picked this one because it distributes well and is simple to implement
unsigned int hash(const char *word)
{
    unsigned long hash_val = 5381;
    for (int i = 0; word[i] != '\0'; i++)
    {
        hash_val = ((hash_val << 5) + hash_val) + tolower(word[i]);
    }
    return hash_val % N;
}

// loads dictionary into memory, returning true if successful
bool load(const char *dictionary)
{
    FILE *source = fopen(dictionary, "r");
    if (source == NULL)
    {
        return false;
    }

    char buffer[LENGTH + 1];

    while (fscanf(source, "%s", buffer) != EOF)
    {
        // create a new node
        node *new_node = malloc(sizeof(node));
        if (new_node == NULL)
        {
            fclose(source);
            return false;
        }

        strcpy(new_node->word, buffer);

        // insert at front of the linked list
        unsigned int idx = hash(buffer);
        new_node->next = table[idx];
        table[idx] = new_node;

        word_count++;
    }

    fclose(source);
    return true;
}

// returns true if word is in dictionary (case-insensitive)
bool check(const char *word)
{
    unsigned int idx = hash(word);
    node *cursor = table[idx];

    while (cursor != NULL)
    {
        if (strcasecmp(cursor->word, word) == 0)
        {
            return true;
        }
        cursor = cursor->next;
    }

    return false;
}

// returns number of words in dictionary if loaded, else 0
unsigned int size(void)
{
    return word_count;
}

// unloads dictionary from memory, returning true if successful
bool unload(void)
{
    for (int i = 0; i < N; i++)
    {
        node *cursor = table[i];
        while (cursor != NULL)
        {
            node *temp = cursor;
            cursor = cursor->next;
            free(temp);
        }
    }
    return true;
}
