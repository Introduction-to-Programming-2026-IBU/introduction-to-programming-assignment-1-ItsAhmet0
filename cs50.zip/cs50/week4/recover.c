#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef uint8_t BYTE;
const int BLOCK_SIZE = 512;

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./recover IMAGE\n");
        return 1;
    }

    FILE *raw = fopen(argv[1], "r");
    if (raw == NULL)
    {
        printf("Could not open %s.\n", argv[1]);
        return 1;
    }

    BYTE buffer[BLOCK_SIZE];
    int file_count = 0;
    FILE *current_jpg = NULL;
    char filename[8]; // "###.jpg\0"

    while (fread(buffer, 1, BLOCK_SIZE, raw) == BLOCK_SIZE)
    {
        // check for jpeg signature
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff &&
            (buffer[3] & 0xf0) == 0xe0)
        {
            // close previous file if there is one
            if (current_jpg != NULL)
            {
                fclose(current_jpg);
            }

            // open a new jpeg file
            sprintf(filename, "%03i.jpg", file_count);
            current_jpg = fopen(filename, "w");
            if (current_jpg == NULL)
            {
                fclose(raw);
                return 1;
            }
            file_count++;
        }

        // if we have an open file, write to it
        if (current_jpg != NULL)
        {
            fwrite(buffer, 1, BLOCK_SIZE, current_jpg);
        }
    }

    // clean up
    if (current_jpg != NULL)
    {
        fclose(current_jpg);
    }
    fclose(raw);
}
